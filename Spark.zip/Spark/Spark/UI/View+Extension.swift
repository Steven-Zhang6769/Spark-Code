//
//  View+Extension.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import Foundation
import SwiftUI
import Popovers

var backgroundView: some View{
    Image("background2")
        .resizable()
        .blur(radius: 30)
        .scaleEffect(1.2)
        .edgesIgnoringSafeArea(.all)
}

struct XButton: View {
    let action: () -> Void
    var size: CGFloat = 34
    var foregroundColor: Color = .secondary
    var withBackground: Bool = true
    
    
    var body: some View {
        if withBackground{
            Button(action: {
                action()
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            }) {
                Image(systemName: "xmark")
                    .font(.system(size: size / 2).bold())
                    .foregroundColor(foregroundColor)
                    .frame(width: size, height: size)
                    .background(.thinMaterial)
                    .clipShape(
                        Circle()
                    )
            }
        }else{
            Button(action: {
                action()
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            }) {
                Image(systemName: "xmark")
                    .font(.system(size: size / 2).bold())
                    .foregroundColor(foregroundColor)
                    .frame(width: size, height: size)
            }
        }
    }
}
struct PopoverModifier<PopoverContent: View>: ViewModifier {
    @Binding var present: Bool
    var ifRubber: Bool = false
    var center = true
    let content: () -> PopoverContent
    var backgroundView: () -> AnyView
    
    var animation: Animation = Animation.spring(response: 0.4, dampingFraction: 0.8, blendDuration: 0.8)
    var transition: AnyTransition = AnyTransition.move(edge: .bottom).combined(with: .opacity)
    
    var glassBackground: some View {
        TransparentBlurView(removeAllFilters: true)
            .blur(radius: 9, opaque: true)
            .background(Color.white.opacity(0.05))
            .shadow(color: .black.opacity(0.25), radius: 10, x: 0, y: 5)
            .cornerRadius(10)
    }

    func body(content: Content) -> some View {
        content
            .popover(
                present: $present,
                attributes: {
                    if center{
                        $0.position = .relative(
                            popoverAnchors: [
                                .center,
                            ]
                        )
                    }else{
                        $0.position = .relative(
                            popoverAnchors: [
                                .top,
                            ]
                        )
                    }
                    
                    if !ifRubber {
                        $0.rubberBandingMode = .none
                    }
                    
                    $0.blocksBackgroundTouches = true
                    
                    $0.presentation.animation = animation
                    $0.presentation.transition = transition
                    $0.dismissal.mode = .none
                },
                view: {
                    self.content()
                },
                background: {
                    self.backgroundView()
                }
            )
    }
}


extension View {
    var glassBackground: some View {
        TransparentBlurView(removeAllFilters: true)
            .blur(radius: 9, opaque: true)
            .background(Color.white.opacity(0.05))
            .shadow(color: .black.opacity(0.25), radius: 10, x: 0, y: 5)
            .cornerRadius(10)
    }

    func fixedPopover<PopoverContent: View>(present: Binding<Bool>, ifRubber: Bool = false, center: Bool = true, @ViewBuilder content: @escaping () -> PopoverContent) -> some View {
        self.modifier(PopoverModifier(present: present, ifRubber: ifRubber, center: center, content: content, backgroundView: {
            AnyView(
                glassBackground
                    .overlay(Color.black.opacity(0.4))
            )
        }))
    }
    
    func darkPopover<PopoverContent: View>(present: Binding<Bool>, ifRubber: Bool = false, @ViewBuilder content: @escaping () -> PopoverContent) -> some View {
        self.modifier(PopoverModifier(present: present, ifRubber: ifRubber, content: content, backgroundView: {
            AnyView(
                glassBackground
                    .overlay(Color.black.opacity(0.9))
            )
        }))
    }
    
    func fadePopover <PopoverContent: View>(present: Binding<Bool>, ifRubber: Bool = false, @ViewBuilder content: @escaping () -> PopoverContent) -> some View {
        self.modifier(PopoverModifier(present: present, ifRubber: ifRubber, content: content, backgroundView: {
            AnyView(
                glassBackground
                    .overlay(Color.black.opacity(0.4))
            )
        },
          animation: Animation.easeInOut(duration: 0.4),
          transition: AnyTransition
            .scale(scale: 0.8)
            .combined(with: .opacity)
     ))
    }
}
