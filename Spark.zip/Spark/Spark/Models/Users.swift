//
//  Users.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import Foundation
import SwiftUI
import Firebase
import FirebaseFirestore

struct User: Identifiable, Codable {
    let id: String
    var streak: Int
    var xp: Int
    var enrolledCourse: String
    var sessionIds: [String]
}
