//
//  Courses.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import Foundation

struct Course: Identifiable {
    let id: String
    let title: String
    let description: String
    let backgroundImage: String
}
