//
//  Session.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import Foundation

//struct Session: Identifiable, Codable, Hashable {
//    let id: String
//    let emoji: String
//    let title: String
//    let subtitle: String
//    let isLocked: Bool
//    let pointsReward: Int
//    let topics: [String]
//    let difficulty: Difficulty
//    var completionStatus: CompletionStatus
//    
enum Difficulty: String, Codable {
    case beginner
    case intermediate
    case advanced
}
//    
//    enum CompletionStatus: String, Codable {
//        case notStarted
//        case inProgress
//        case completed
//    }
//    
//    init(emoji: String, title: String, subtitle: String, isLocked: Bool, pointsReward: Int, topics: [String], difficulty: Difficulty, completionStatus: CompletionStatus = .notStarted) {
//        self.id = UUID().uuidString
//        self.emoji = emoji
//        self.title = title
//        self.subtitle = subtitle
//        self.isLocked = isLocked
//        self.pointsReward = pointsReward
//        self.topics = topics
//        self.difficulty = difficulty
//        self.completionStatus = completionStatus
//    }
//}
struct Session: Identifiable, Hashable{
    let id: String
    let title: String
    
    // These properties are not fetched from Firestore, but we'll keep them for UI purposes
    let emoji: String
    let subtitle: String
    let isLocked: Bool
    let pointsReward: Int
    let topics: [String]
    let assistantID: String
    
    init(id: String, title: String, assistantID: String) {
        self.id = id
        self.title = title
        
        // Set default values or randomize these properties
        self.emoji = ["🍏", "🚀", "🧠", "💡", "🔬", "🎨", "📚"].randomElement() ?? "📚"
        self.subtitle = "Explore this session"
        self.isLocked = false
        self.pointsReward = Int.random(in: 50...200)
        self.topics = ["Algorithms", "Data Structures", "Problem Solving"]
        self.assistantID = assistantID
//        self.difficulty = [Difficulty.beginner, .intermediate, .advanced].randomElement() ?? .intermediate
    }
}

