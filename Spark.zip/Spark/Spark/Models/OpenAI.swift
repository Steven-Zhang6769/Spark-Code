//
//  OpenAI.swift
//  Airy
//
//  Created by Shuhan Zhang on 2023/11/13.
//

import Foundation

//MARK: - OpenAI structs
struct Tool: Codable {
    var type: String
}

enum Object: String, Codable {
    case thread = "thread"
    case assistant = "assistant"
    case message = "thread.message"
    case run = "thread.run"
}

struct Assistant: Codable {
    var id: String
    var object: Object
    var createdAt: Int
    var name: String
    var description: String?
    var model: String
    var instructions: String
    var tools: [Tool]
    var metadata: [String: String]

    enum CodingKeys: String, CodingKey {
        case id
        case object
        case createdAt = "created_at"
        case name
        case description
        case model
        case instructions
        case tools
        case metadata
    }
}



struct Thread: Codable{
    var id: String
    var object: String
    var createdAt: Int
    var metadata: [String: String]
    
    enum CodingKeys: String, CodingKey {
        case id
        case object
        case createdAt = "created_at"
        case metadata
    }
}

struct MessageResponse: Decodable {
    let data: [Message]
}



struct Message: Codable {
    var id: String
    var object: String
    var createdAt: Int
    var threadId: String
    var role: String
    var content: [ContentItem]
    var assistantId: String?
    var runId: String?
    var metadata: [String: String]

    enum CodingKeys: String, CodingKey {
        case id
        case object
        case createdAt = "created_at"
        case threadId = "thread_id"
        case role
        case content
        case assistantId = "assistant_id"
        case runId = "run_id"
        case metadata
    }

    struct ContentItem: Codable {
        var type: String
        var text: TextContent?
        
        struct TextContent: Codable {
            var value: String
            var annotations: [Annotation]

            struct Annotation: Codable {
                // Define according to the expected structure of annotations
            }
        }
    }
    func convertToLearnMore() throws -> String {
        guard let jsonContent = self.content[0].text?.value else {
            throw NSError(domain: "LearnMoreError", code: 0, userInfo: [NSLocalizedDescriptionKey: "No JSON content found"])}


        // Step 2: Decode the JSON string to DiaryEntry
        print(jsonContent)
        
        guard let jsonData = jsonContent.data(using: .utf8) else {
            print("error converting json data")
            throw NSError(domain: "LearnMoreError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON data"])
        }
        
        let decoder = JSONDecoder()

        return try decoder.decode(String.self, from: jsonData)
    }
    
    func convertToQuestions() throws -> [Question]? {
        guard let jsonContent = self.content[0].text?.value else {
            throw NSError(domain: "QuestionsError", code: 0, userInfo: [NSLocalizedDescriptionKey: "No JSON content found"])
        }
        
        guard let startIndex = jsonContent.firstIndex(of: "["),
               let endIndex = jsonContent.lastIndex(of: "]") else {
             print("Could not find JSON array in the text.")
             return nil
         }
         
         // Extract the JSON string
         let jsonString = String(jsonContent[startIndex...endIndex])


        print("trimmed", jsonString)

        
        guard let jsonData = jsonString.data(using: .utf8) else {
            print("error converting json data")
            throw NSError(domain: "QuestionsError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON data"])
        }
        
        let decoder = JSONDecoder()
        
        return try decoder.decode([Question].self, from: jsonData)
    }
}

struct Run: Codable {
    var id: String
    var object: String
    var createdAt: Int
    var assistantId: String
    var threadId: String
    var status: String
    var expiresAt: Int?
    var startedAt: Int?
    var cancelledAt: Int?
    var failedAt: Int?
    var completedAt: Int?
    var model: String
    var instructions: String?
    var tools: [Tool]
    var metadata: [String: String]

    enum CodingKeys: String, CodingKey {
        case id
        case object
        case createdAt = "created_at"
        case assistantId = "assistant_id"
        case threadId = "thread_id"
        case status
        case expiresAt = "expires_at"
        case startedAt = "started_at"
        case cancelledAt = "cancelled_at"
        case failedAt = "failed_at"
        case completedAt = "completed_at"
        case model
        case instructions
        case tools
        case metadata
    }
    var statusDisplay: String {
         switch status {
         case "queued":
             return "Queued"
         case "in_progress":
             return "In Progress"
         case "requires_action":
             return "Requires Action"
         case "cancelling":
             return "Cancelling"
         case "cancelled":
             return "Cancelled"
         case "failed":
             return "Failed"
         case "completed":
             return "Completed"
         case "expired":
             return "Expired"
         default:
             return "Unknown"
         }
     }
}

struct MessageDelta: Codable{
    let id: String
    let object: String
    let delta: DeltaContent
    
    struct DeltaContent: Codable {
        let content: [ContentItem]
    }
    
    struct ContentItem: Codable {
        let index: Int
        let type: String
        let text: TextContent
    }
    
    struct TextContent: Codable {
        let value: String
        var annotations: [String]

        enum CodingKeys: String, CodingKey {
            case value, annotations
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            value = try container.decode(String.self, forKey: .value)
            annotations = try container.decodeIfPresent([String].self, forKey: .annotations) ?? []
        }
    }

}

