//
//  FirebaseServices.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import Foundation
import Firebase
import FirebaseFirestore

class FirebaseService: ObservableObject {
    private let db = Firestore.firestore()
    
    @Published var professors: [Professor] = []
    @Published var courses: [Course] = []
    @Published var sessions: [Session] = []
    
    func fetchProfessors() {
        db.collection("professors").getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching professors: \(error)")
                return
            }
            
            self.professors = snapshot?.documents.compactMap { document in
                let data = document.data()
                return Professor(id: document.documentID, name: data["name"] as? String ?? "")
            } ?? []
        }
    }
    
    func fetchCourses(for professorId: String) {
        db.collection("professors").document(professorId).collection("classes").getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching courses: \(error)")
                return
            }
            
            self.courses = snapshot?.documents.compactMap { document in
                let data = document.data()
                return Course(
                    id: document.documentID,
                    title: data["title"] as? String ?? "",
                    description: data["description"] as? String ?? "",
                    backgroundImage: data["backgroundImage"] as? String ?? "background"
                )
            } ?? []
        }
    }
    
    func fetchSessions(for courseId: String) {
        guard !courseId.isEmpty else { return }
        
        db.collection("professors").getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching professors: \(error)")
                return
            }
            
            for document in snapshot?.documents ?? [] {
                self.fetchSessionsForProfessor(professorId: document.documentID, courseId: courseId)
            }
        }
    }
    
    private func fetchSessionsForProfessor(professorId: String, courseId: String) {
        db.collection("professors").document(professorId)
            .collection("classes").document(courseId)
            .collection("sessions").getDocuments { (snapshot, error) in
                if let error = error {
                    print("Error fetching sessions: \(error)")
                    return
                }
                
                let newSessions = snapshot?.documents.compactMap { document -> Session? in
                    let data = document.data()
                    guard let sessionTitle = data["session_title"] as? String else { return nil }
                    guard let assistant = data["assistantId"] as? String else { return nil }
                    return Session(id: document.documentID, title: sessionTitle, assistantID: assistant)
                } ?? []
                
                DispatchQueue.main.async {
                    self.sessions.append(contentsOf: newSessions)
                    self.sessions.shuffle() // Randomize the order of sessions
                }
            }
    }
    
    func enrollUserInCourse(userId: String, courseId: String, completion: @escaping (Bool) -> Void) {
        let userRef = db.collection("users").document(userId)
        
        userRef.updateData(["enrolledCourse": courseId]) { error in
            if let error = error {
                print("Error enrolling user in course: \(error)")
                completion(false)
            } else {
                print("User successfully enrolled in course")
                completion(true)
            }
        }
    }
}
struct Professor: Identifiable {
    let id: String
    let name: String
}
