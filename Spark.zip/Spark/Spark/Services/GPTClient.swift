//
//  GPTClient.swift
//  Airy
//
//  Created by Shuhan Zhang on 2023/11/13.
//

import Foundation

class GPTClient{
    private let openAIKey = "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"
    private var dataBuffer = ""
    
    private var isCompleted = false
    
    // MARK: - API URLs
    enum AssistantAPIUrl {
        case createThreadAndRun
        case createThread
        case createMessage(_ thread_id: String)
        case createRun(_ thread_id: String)
        case retrieveRun(_ thread_id: String, _ run_id: String)
        case retreiveThread(_ thread_id: String)
        case listMessages(_ thread_id: String)
        case custom(_ url: URL)
        
        var url: URL {
            switch self {
            case .createThreadAndRun:
                return URL(string: "https://api.openai.com/v1/threads/runs")!
            case .createThread:
                return URL(string: "https://api.openai.com/v1/threads")!
            case .createMessage(let thread_id):
                return URL(string: "https://api.openai.com/v1/threads/\(thread_id)/messages")!
            case .createRun(let thread_id):
                return URL(string: "https://api.openai.com/v1/threads/\(thread_id)/runs")!
            case .retrieveRun(let thread_id, let run_id):
                return URL(string: "https://api.openai.com/v1/threads/\(thread_id)/runs/\(run_id)")!
            case .retreiveThread(let thread_id):
                return URL(string: "https://api.openai.com/v1/threads/\(thread_id)")!
            case .listMessages(let thread_id):
                return URL(string: "https://api.openai.com/v1/threads/\(thread_id)/messages")!
            case .custom(let url):
                return url
            }
        }
    }
    
    // MARK: - API Request functions
    private func makeRequest(url: URL, method: String, body: Data? = nil) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.addValue("Bearer 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", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("assistants=v2", forHTTPHeaderField: "OpenAI-Beta")
        request.httpBody = body
        return request
    }
    
    func createThreadAndRun(_ assistant_id: String, _ message: String) async throws -> Run{
        let requestBody: [String : Any] = [
            "assistant_id": assistant_id,
            "thread": [
                "messages": [
                    ["role": "user", "content": message]
                ]
            ]
        ]
        
        let requestData = try JSONSerialization.data(withJSONObject: requestBody)
        let request = makeRequest(url: AssistantAPIUrl.createThreadAndRun.url, method: "POST", body: requestData)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        
        if let dataString = String(data: data, encoding: .utf8) {
            print(dataString)
        } else {
            print("Unable to convert data to string.")
        }
        return try JSONDecoder().decode(Run.self, from: data)
    }
    
    func createThread(message: String) async throws -> Thread{
        let requestBody = [
            "messages": [
                ["role": "user", "content": message]
            ]
        ]
        
        let requestData = try JSONSerialization.data(withJSONObject: requestBody)
        let request =  makeRequest(url: AssistantAPIUrl.createThread.url, method: "POST", body: requestData)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        
        if let dataString = String(data: data, encoding: .utf8) {
            print("Response data: \(dataString)")
        } else {
            print("Failed to convert data to string.")
        }
        
        return try JSONDecoder().decode(Thread.self, from: data)
    }
    
    
    func createMessage (_ thread_id: String, _ content: String) async throws-> Message{
        let requestBody = [
            "role": "user",
            "content": content
        ]
        
        let requestData = try JSONSerialization.data(withJSONObject: requestBody)
        let request =  makeRequest(url: AssistantAPIUrl.createMessage(thread_id).url, method: "POST", body: requestData)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(Message.self, from: data)
    }
    
    func createRun(_ thread_id:String, _ assistant_id: String) async throws -> Run{
        let requestBody = [
            "assistant_id": assistant_id,
        ]
        
        let requestData = try JSONSerialization.data(withJSONObject: requestBody)
        let request =  makeRequest(url: AssistantAPIUrl.createRun(thread_id).url, method: "POST", body: requestData)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(Run.self, from: data)
    }
    
    func retrieveRun(_ thread_id:String, _ run_id: String) async throws -> Run{
        let request =  makeRequest(url: AssistantAPIUrl.retrieveRun(thread_id, run_id).url, method: "GET")
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(Run.self, from: data)
    }
    
    func retreiveThread(_ thread_id: String) async throws -> Thread{
        let request =  makeRequest(url: AssistantAPIUrl.retreiveThread(thread_id).url, method: "GET")
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(Thread.self, from: data)
    }
    
    func listMessages(_ thread_id: String) async throws -> [Message]{
        let request = makeRequest(url: AssistantAPIUrl.listMessages(thread_id).url, method: "GET")
        
        let (data, _) = try await URLSession.shared.data(for: request)
        if let string = String(data: data, encoding: .utf8) {
        } else {
            print("Unable to convert data to string.")
        }
        let response = try JSONDecoder().decode(MessageResponse.self, from: data)
        return response.data
    }
    
    
    func streamRun(_ thread_id: String, assistant_id: String, onUpdate: @escaping (String) -> Void, onComplete: @escaping () -> Void) throws {
        isCompleted = false
        print("Starting stream for thread ID: \(thread_id) with assistant ID: \(assistant_id)")
        
        let requestBody: [String: Any] = [
            "assistant_id": assistant_id,
            "stream": true
        ]
        
        let requestData = try JSONSerialization.data(withJSONObject: requestBody)
        let request = makeRequest(url: AssistantAPIUrl.createRun(thread_id).url, method: "POST", body: requestData)
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print("Error streaming run events: \(String(describing: error))")
                return
            }
            
            if let dataString = String(data: data, encoding: .utf8) {
                print("Stream data received: \(dataString)")
                self.processStreamData(dataString, onUpdate: onUpdate, onComplete: onComplete)
            } else {
                print("Failed to convert data to string.")
            }
        }
        task.resume()
    }

    private func processStreamData(_ newDataString: String, onUpdate: @escaping (String) -> Void, onComplete: @escaping () -> Void) {
        dataBuffer += newDataString  // Append new data to buffer
        
        var lines = dataBuffer.split(separator: "\n", omittingEmptySubsequences: false)
        var lastIndex = 0
        
        for (index, line) in lines.enumerated() {
            if line.isEmpty {
                let eventChunk = lines[0..<index]
                processEventChunk(Array(eventChunk), onUpdate: onUpdate, onComplete: onComplete)
                lastIndex = index + 1
            }
        }
        
        dataBuffer = Array(lines[lastIndex...]).joined(separator: "\n")
    }

    private func processEventChunk(_ lines: [Substring], onUpdate: @escaping (String) -> Void, onComplete: @escaping () -> Void) {
        var eventType: String?
        var jsonData: String?
        
        for line in lines {
            let strLine = String(line)
            if strLine.starts(with: "event:") {
                eventType = strLine.replacingOccurrences(of: "event: ", with: "")
            } else if strLine.starts(with: "data:") {
                if strLine.contains("[DONE]") {
                    print("[DONE] signal received")
                    if !isCompleted {
                        isCompleted = true
                        onComplete()
                    }
                    return
                }
                jsonData = strLine.replacingOccurrences(of: "data: ", with: "")
            }
        }
        
        if let eventType = eventType, let jsonData = jsonData {
            do {
                try handleStreamedEvent(eventType: eventType, jsonDataString: jsonData, onUpdate: onUpdate)
            } catch {
                print("Error handling streamed event: \(error)")
            }
        }
    }

    private func handleStreamedEvent(eventType: String, jsonDataString: String, onUpdate: @escaping (String) -> Void) throws {
        print("Handling streamed event for type: \(eventType)")
        if let jsonData = jsonDataString.data(using: .utf8) {
            switch eventType {
            case "thread.message.delta":
                if let messageDelta = try? JSONDecoder().decode(MessageDelta.self, from: jsonData) {
                    print("messageDelta", messageDelta)
                    onUpdate(messageDelta.delta.content[0].text.value)
                } else {
                    print("messageDelta not processed", jsonDataString)
                }
            case "thread.run.failed":
                print("Stream run failed with data: \(jsonDataString)")
                throw NSError(domain: "com.yourdomain.app", code: -1, userInfo: [NSLocalizedDescriptionKey: "Stream run failed."])
            default:
                print("Event \(eventType) received with data: \(jsonData)")
            }
        }
    }

}
