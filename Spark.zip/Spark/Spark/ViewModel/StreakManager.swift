//
//  StreakManager.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import Foundation
import FirebaseFirestore

class StreakManager {
    private let userManager: UserManager
    private let defaults = UserDefaults.standard
    
    init(userManager: UserManager) {
        self.userManager = userManager
    }
    
    func checkAndUpdateStreak() {
        guard let userId = userManager.currentUser?.id else { return }
        
        let lastActivityDate = defaults.object(forKey: "lastActivityDate_\(userId)") as? Date ?? Date.distantPast
        let currentDate = Date()
        
        if !Calendar.current.isDate(lastActivityDate, inSameDayAs: currentDate) {
            if let daysBetween = Calendar.current.dateComponents([.day], from: lastActivityDate, to: currentDate).day {
                if daysBetween == 1 {
                    // User was active yesterday, increment streak
                    incrementStreak(userId: userId)
                } else if daysBetween > 1 {
                    // User missed a day, reset streak
                    resetStreak(userId: userId)
                }
            }
        }
        
        // Update last activity date
        defaults.set(currentDate, forKey: "lastActivityDate_\(userId)")
    }
    
    private func incrementStreak(userId: String) {
        userManager.incrementStreak(userId: userId)
    }
    
    private func resetStreak(userId: String) {
        userManager.updateUser(userId: userId, updates: ["streak": 0])
    }
    
    func recordDailyActivity() {
        checkAndUpdateStreak()
    }
}
