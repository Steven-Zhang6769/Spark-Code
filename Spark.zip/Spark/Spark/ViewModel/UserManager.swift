import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth

class UserManager: ObservableObject {
    @Published var currentUser: User?
    @Published var isLoading = true
    private var db = Firestore.firestore()
    private var streakManager: StreakManager?
    
    init() {
        setupAuthStateListener()
        self.streakManager = StreakManager(userManager: self)
    }
    
    private func setupAuthStateListener() {
        Auth.auth().addStateDidChangeListener { [weak self] (auth, user) in
            guard let self = self else { return }
            if let firebaseUser = user {
                self.fetchUser(userId: firebaseUser.uid)
            } else {
                self.currentUser = nil
                self.isLoading = false
            }
        }
    }
    
    func recordDailyActivity() {
        streakManager?.recordDailyActivity()
    }
    
    func incrementStreak(userId: String) {
        let increment = FieldValue.increment(Int64(1))
        updateUser(userId: userId, updates: ["streak": increment])
    }
    
    func createUser(userId: String, completion: @escaping (Result<User, Error>) -> Void) {
        let newUser = User(id: userId, streak: 0, xp: 0, enrolledCourse: "", sessionIds: [])
        do {
            try db.collection("users").document(userId).setData(from: newUser) { error in
                if let error = error {
                    print("Error writing document: \(error)")
                    completion(.failure(error))
                } else {
                    print("Document successfully written!")
                    self.currentUser = newUser
                    self.isLoading = false
                    completion(.success(newUser))
                }
            }
        } catch {
            print("Error encoding user: \(error)")
            completion(.failure(error))
        }
    }
    
    func fetchUser(userId: String) {
        db.collection("users").document(userId).getDocument { [weak self] document, error in
            guard let self = self else { return }
            if let document = document, document.exists {
                do {
                    self.currentUser = try document.data(as: User.self)
                    self.isLoading = false
                } catch {
                    print("Error decoding user: \(error)")
                    self.isLoading = false
                }
            } else {
                print("User does not exist")
                self.createUser(userId: userId) { result in
                    print("User creation result:", result)
                }
            }
        }
    }
    
    
    func updateUser(userId: String, updates: [String: Any]) {
        db.collection("users").document(userId).updateData(updates) { error in
            if let error = error {
                print("Error updating user: \(error)")
            } else {
                self.fetchUser(userId: userId)
            }
        }
    }
    
    func addXP(userId: String, amount: Int) {
        let increment = FieldValue.increment(Int64(amount))
        updateUser(userId: userId, updates: ["xp": increment])
    }
    
    func addCourse(userId: String, courseId: String) {
        let arrayUnion = FieldValue.arrayUnion([courseId])
        updateUser(userId: userId, updates: ["courseIds": arrayUnion])
    }
    
    func addSession(userId: String, sessionId: String) {
        let arrayUnion = FieldValue.arrayUnion([sessionId])
        updateUser(userId: userId, updates: ["sessionIds": arrayUnion])
    }
    
    func signOut() {
        do {
            try Auth.auth().signOut()
            self.currentUser = nil
        } catch {
            print("Error signing out: \(error)")
        }
    }
}
