import SwiftUI

struct CourseListView: View {
    @ObservedObject var userManager: UserManager
    @StateObject private var firebaseService = FirebaseService()
    @State private var selectedProfessor: Professor?
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Professors")) {
                    ForEach(firebaseService.professors) { professor in
                        Text(professor.name)
                            .onTapGesture {
                                selectedProfessor = professor
                                firebaseService.fetchCourses(for: professor.id)
                            }
                    }
                }
                
                if let _ = selectedProfessor {
                    Section(header: Text("Courses")) {
                        ForEach(firebaseService.courses) { course in
                            CourseCard(course: course, userManager: userManager, firebaseService: firebaseService)
                                .frame(height: 200)
                                .listRowInsets(EdgeInsets())
                                .padding(.vertical, 8)
                        }
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Courses")
            .onAppear {
                firebaseService.fetchProfessors()
            }
        }
    }
}

struct CourseCard: View {
    let course: Course
    @ObservedObject var userManager: UserManager
    @ObservedObject var firebaseService: FirebaseService
    @State private var isEnrolled = false
    
    var body: some View {
        ZStack {
            Image(course.backgroundImage)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 200)
                .clipped()
            
            VStack {
                Spacer()
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(course.title)
                        .font(.title2)
                        .fontWeight(.black)
                        .foregroundColor(.white)
                    
                    Text(course.description)
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(.white.opacity(0.8))
                    
                    Spacer()
                    
                    HStack {
                        Spacer()
                        Button(action: {
                            enrollInCourse(courseId: course.id)
                        }) {
                            Text(isEnrolled ? "Enrolled" : "Enroll")
                                .font(.headline)
                                .fontWeight(.heavy)
                                .foregroundColor(.white)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(isEnrolled ? Color.green : Color.blue)
                                .cornerRadius(20)
                        }
                        .disabled(isEnrolled)
                    }
                }
                .padding()
            }
            .background(Color.black.opacity(0.6))
        }
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 4)
        .onAppear {
            isEnrolled = userManager.currentUser?.enrolledCourse == course.id
        }
    }
    
    private func enrollInCourse(courseId: String) {
        if let userId = userManager.currentUser?.id {
            firebaseService.enrollUserInCourse(userId: userId, courseId: courseId) { success in
                if success {
                    userManager.currentUser?.enrolledCourse = courseId
                    isEnrolled = true
                }
            }
        }
    }
}

struct CourseListView_Previews: PreviewProvider {
    static var previews: some View {
        CourseListView(userManager: UserManager())
    }
}
