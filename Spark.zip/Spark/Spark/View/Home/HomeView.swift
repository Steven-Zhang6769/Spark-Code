//
//  HomeView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI
import Popovers

struct HomeView: View {
    @State var selectedSession: Session?
    @ObservedObject var userManager: UserManager
    
    private var statItems: [StatItem] {
        [
            StatItem(icon: "book.closed", value: "CS347"),
            StatItem(icon: "flame", value: "\(userManager.currentUser?.streak ?? 0)"),
            StatItem(icon: "trophy.fill", value: "\(userManager.currentUser?.xp ?? 0)")
        ]
    }

    let sessions = [
        Session(id: "1", title: "NP VS P", assistantID: "asst_aKrXGIkCF05JO37IbudL7T9Q"),
        Session(id: "2", title: "Simple Reductions", assistantID: "asst_1XsI8ADbgvYyPE0R2X71uyb2"),
        Session(id: "3", title: "Divide and Conquere", assistantID: "asst_1XsI8ADbgvYyPE0R2X71uyb2")
    ]
    
    var body: some View {
        VStack(spacing: 20) {
            StatRow(items: statItems)
                .padding(.horizontal)
            
            Text("Your Sessions")
                .font(.title2)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)
            
            SessionMapView(sessions: sessions)
            
            Spacer()
        }
        .navigationDestination(item: $selectedSession) { session in
            SessionView(assistantID: "asst_1XsI8ADbgvYyPE0R2X71uyb2", session: session, questions: [], userManager: userManager)
        }
    }
}

struct SessionMapView: View {
    let sessions: [Session]
    @State private var scrollPosition: CGFloat = 0
    @State private var showScrollToTop = false
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(Array(sessions.enumerated()), id: \.element.id) { index, session in
                        SessionCard(session: session)
                            .frame(width: 200, height: 250)
                            .offset(x: index.isMultiple(of: 2) ? -50 : 50)
                            .id(index) // Add an id for scrolling
                        
                        if index < sessions.count - 1 {
                            Path { path in
                                path.move(to: CGPoint(x: index.isMultiple(of: 2) ? 150 : 250, y: 0))
                                path.addLine(to: CGPoint(x: index.isMultiple(of: 2) ? 250 : 150, y: 70))
                            }
                            .stroke(Color.gray, style: StrokeStyle(lineWidth: 3, dash: [5]))
                        }
                    }
                }
                .background(GeometryReader { geometry in
                    Color.clear.preference(key: ScrollOffsetPreferenceKey.self, value: geometry.frame(in: .named("scroll")).origin.y)
                })
            }
            .coordinateSpace(name: "scroll")
            .onPreferenceChange(ScrollOffsetPreferenceKey.self) { value in
                scrollPosition = value
                showScrollToTop = value < -100 // Show button when scrolled down 100 points
            }
            .overlay(
                VStack {
                    Spacer()
                    
                    if showScrollToTop {
                        Button(action: {
                            withAnimation {
                                proxy.scrollTo(0, anchor: .top)
                            }
                        }) {
                            Image(systemName: "arrow.up")
                                .foregroundColor(.theme)
                                .font(.headline)
                                .fontWeight(.black)
                                .padding(15)
                                .background(.thinMaterial)
                                .clipShape(Circle())
                                .shadow(radius: 10)
                        }
                        .padding(.bottom, 20)
                        .transition(.opacity)
                    }
                }
            )
        }
    }
}

struct ScrollOffsetPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value += nextValue()
    }
}


struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(userManager: UserManager())
    }
}
