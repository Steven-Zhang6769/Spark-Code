//
//  StatComponent.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI

struct StatCell: View {
    let emoji: String
    let stat: String
    let statDescription: String
    
    var body: some View {
        HStack(spacing: 16) {
            Text(emoji)
                .font(.system(size: 40))
                .frame(width: 60, height: 60)
                .background(Color.gray.opacity(0.2))
                .clipShape(Circle())
            
            VStack(alignment: .leading, spacing: 4) {
                Text(stat)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(statDescription)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 4)
    }
}


#Preview {
    VStack(spacing: 16) {
        StatCell(emoji: "🔥", stat: "3", statDescription: "Day streak")
        StatCell(emoji: "💎", stat: "1,234", statDescription: "Total XP")
        StatCell(emoji: "🏆", stat: "5", statDescription: "Achievements")
    }
    .padding()
}
