//
//  StatColumn.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI

struct StatItem: Identifiable {
    let id = UUID()
    let icon: String
    let value: String
}

struct StatItemView: View {
    let item: StatItem
    
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: item.icon)
                .font(.system(size: 16))
                .fontWeight(.black)
                .foregroundStyle(.theme)
            
            Text(item.value)
                .font(.subheadline.bold())
        }
    }
}

struct StatRow: View {
    let items: [StatItem]
    
    var body: some View {
        HStack {
            ForEach(items) { item in
                StatItemView(item: item)
                if item.id != items.last?.id {
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 4)
    }
}


#Preview {
    let statItems = [
        StatItem(icon: "book.closed", value: "CS347"),
        StatItem(icon: "flame", value: "12"),
        StatItem(icon: "heart", value: "5")
    ]
    
    return StatRow(items: statItems)
}
