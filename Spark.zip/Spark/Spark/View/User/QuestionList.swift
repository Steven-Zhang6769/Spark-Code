//
//  QuestionList.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import SwiftUI
import SwiftData

struct QuestionListView: View {
    @Query private var questions: [Question]
    @State private var selectedQuestion: Question?
    @State private var showingDetail = false

    var body: some View {
        List(questions) { question in
            QuestionCell(question: question)
                .onTapGesture {
                    selectedQuestion = question
                    showingDetail = true
                }
        }
        .sheet(isPresented: $showingDetail) {
            if let selectedQuestion = selectedQuestion {
                QuestionDetailView(question: selectedQuestion)
            }
        }
    }
}

struct QuestionCell: View {
    let question: Question

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(question.title)
                .font(.headline)
            Text(question.subTitle)
                .font(.subheadline)
                .foregroundColor(.secondary)
            HStack {
                Text(question.questionType.rawValue.capitalized)
                    .font(.caption)
                    .padding(4)
                    .background(typeColor(for: question.questionType))
                    .cornerRadius(4)
                Spacer()
                if let choices = question.choices {
                    Text("\(choices.count) choices")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(.vertical, 8)
    }

    func typeColor(for type: QuestionType) -> Color {
        switch type {
        case .multipleChoice:
            return .blue.opacity(0.2)
        case .trueFalse:
            return .green.opacity(0.2)
        case .shortAnswer:
            return .orange.opacity(0.2)
        }
    }
}

struct QuestionDetailView: View {
    let question: Question

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(question.title)
                    .font(.title)
                    .fontWeight(.bold)
                
                Text(question.subTitle)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Question Type:")
                        .font(.headline)
                    Text(question.questionType.rawValue.capitalized)
                        .padding(6)
                        .background(QuestionCell(question: question).typeColor(for: question.questionType))
                        .cornerRadius(6)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Correct Answer:")
                        .font(.headline)
                    Text(question.correctAnswer)
                        .padding(6)
                        .background(Color.green.opacity(0.2))
                        .cornerRadius(6)
                }
                
                if let choices = question.choices {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Choices:")
                            .font(.headline)
                        ForEach(choices, id: \.self) { choice in
                            Text(choice)
                                .padding(6)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(6)
                        }
                    }
                }
                
                if let feedback = question.feedback {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Personalized Feedback: \(feedback)")
                            .font(.headline)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Question Details")
    }
}

struct QuestionCardView_Previews: PreviewProvider {
    static var previews: some View {
        QuestionListView()
    }
}
