//
//  SessionSummary.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import SwiftUI

struct SessionSummaryView: View {
    let totalXP: Int
    let percentCorrect: Int
    let timeSpent: String
    
    var body: some View {
        VStack(spacing: 30) {
            HStack(alignment: .bottom, spacing: -20) {
                Text("🍎")
                    .font(.system(size: 100))
            }
            
            Text("Lesson complete!")
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(.primary)
            
            // Stats display
            HStack(spacing: 20) {
                StatView(label: "TOTAL XP", value: "\(totalXP)", icon: "bolt.fill", color: .yellow)
                StatView(label: "PERFECT!", value: "\(percentCorrect)%", icon: "checkmark.circle.fill", color: .green)
                StatView(label: "SPEEDY", value: timeSpent, icon: "clock.fill", color: .blue)
            }
            
            // Claim XP button
            Button(action: {
                // Add action to claim XP
            }) {
                Text("CLAIM XP")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.theme)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .padding(30)
        .background(.ultraThinMaterial)
        .cornerRadius(20)
        .padding()
    }
}

struct StatView: View {
    let label: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 5) {
            Text(label)
                .font(.caption)
                .foregroundColor(.gray)
            HStack(spacing: 5) {
                Image(systemName: icon)
                    .foregroundColor(color)
                Text(value)
                    .fontWeight(.bold)
                    .foregroundColor(color)
            }
        }
        .padding(10)
        .background(color.opacity(0.1))
        .cornerRadius(10)
    }
}

struct SessionSummaryView_Previews: PreviewProvider {
    static var previews: some View {
        SessionSummaryView(totalXP: 25, percentCorrect: 100, timeSpent: "2:17")
            .preferredColorScheme(.dark)
    }
}
