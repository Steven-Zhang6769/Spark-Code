//
//  SummaryView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import SwiftUI

struct SummaryView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SummaryView()
}
