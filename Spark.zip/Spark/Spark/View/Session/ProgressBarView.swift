//
//  ProgressBarView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI

struct ProgressBarView: View {
    let progress: Double
    let streak: Int
    
    var body: some View {
        VStack {
            HStack{
                
            }
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Rectangle()
                        .foregroundColor(.gray.opacity(0.3))
                    
                    Rectangle()
                        .foregroundColor(.green)
                        .frame(width: geometry.size.width * CGFloat(progress))
                }
            }
            .frame(height: 15)
            .cornerRadius(20)
            
            HStack {
                Text("\(Image(systemName: "flame")) \(streak)")
                    .font(.subheadline)
                    .fontWeight(.heavy)
                    .foregroundColor(.theme)
                
                Spacer()
                
                Text(encouragement)
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(.gray)
            }
        }
        .padding()
    }
    
    private var encouragement: String {
        switch streak {
        case 0...2:
            return "Keep going!"
        case 3...5:
            return "You're doing great!"
        default:
            return "Fantastic job!"
        }
    }
}

#Preview {
    ProgressBarView(progress: 0.5, streak: 2)
}
