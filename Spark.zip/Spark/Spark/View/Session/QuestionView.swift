//
//  QuestionView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI

struct QuestionView: View {
    let question: Question
    let onAnswerSelected: (String) -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text(question.title)
                .font(.title2)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
            
            Text(question.subTitle)
                .font(.body)
                .bold()
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.bottom)
            
            switch question.questionType {
            case .multipleChoice:
                MultipleChoiceQuestionView(question: question, onAnswerSelected: onAnswerSelected)
            case .trueFalse:
                TrueFalseQuestionView(question: question, onAnswerSelected: onAnswerSelected)
            case .shortAnswer:
                ShortAnswerQuestionView(question: question, onAnswerSelected: onAnswerSelected)
            }
        }
        .padding()
    }
}

struct MultipleChoiceQuestionView: View {
    let question: Question
    let onAnswerSelected: (String) -> Void
    @State private var selectedAnswer: String?
    
    var body: some View {
         Group {
             if let choices = question.choices {
                 if choices.count % 2 == 0 {
                     // Even number of choices: 2 columns
                     LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                         ForEach(choices, id: \.self) { choice in
                             choiceButton(for: choice)
                         }
                     }
                 } else {
                     // Odd number of choices: 1 column
                     LazyVStack(spacing: 20) {
                         ForEach(choices, id: \.self) { choice in
                             choiceButton(for: choice)
                         }
                     }
                 }
             } else {
                 Text("No choices available")
             }
         }
         .padding()
     }
    
    private func choiceButton(for choice: String) -> some View {
        Button(action: {
            selectedAnswer = choice
            onAnswerSelected(choice)
            hapticFeedback()
        }) {
            Text(choice)
                .font(.headline)
                .padding()
                .frame(maxWidth: .infinity, minHeight: 100)
                .background(backgroundColor(for: choice))
                .foregroundColor(.white)
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 4)
        }
    }
    
    private func backgroundColor(for choice: String) -> Color {
        guard let selectedAnswer = selectedAnswer else {
            return .blue
        }
        if choice == selectedAnswer {
            return choice == question.correctAnswer ? .green : .red
        }
        return .blue
    }
    
    private func hapticFeedback() {
        let impact = UIImpactFeedbackGenerator(style: .medium)
        impact.impactOccurred()
    }
}

struct TrueFalseQuestionView: View {
    let question: Question
    let onAnswerSelected: (String) -> Void
    @State private var selectedAnswer: String?
    
    var body: some View {
        HStack(spacing: 20) {
            ForEach(["True", "False"], id: \.self) { choice in
                Button(action: {
                    selectedAnswer = choice
                    onAnswerSelected(choice)
                }) {
                    Text(choice)
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(backgroundColor(for: choice))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 4)
                }
            }
        }
    }
    
    private func backgroundColor(for choice: String) -> Color {
        guard let selectedAnswer = selectedAnswer else {
            return .blue
        }
        if choice == selectedAnswer {
            return choice == question.correctAnswer ? .green : .red
        }
        return .blue
    }
}

struct ShortAnswerQuestionView: View {
    let question: Question
    let onAnswerSelected: (String) -> Void
    @State private var answer = ""
    @FocusState var inputFocused: Bool
    
    var body: some View {
        VStack(){
            ZStack(alignment: .top) {
                Color.clear
                    .background(.ultraThinMaterial)
                    .cornerRadius(20)
                    .onTapGesture {
                        inputFocused.toggle()
                    }
                    .frame(height: UIScreen.main.bounds.height * 0.4)
                
                TextField("Your answer...", text: $answer)
                    .font(.title2)
                    .fontWeight(.black)
                    .foregroundColor(.primary)
                    .padding()
                    .focused($inputFocused)
            }
            
            Spacer()
            
            Button(action: {
                onAnswerSelected(answer)
            }) {
                Text("Submit")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
                    .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 4)
            }
            .disabled(answer.isEmpty)
            .padding()
        }
    }
}
