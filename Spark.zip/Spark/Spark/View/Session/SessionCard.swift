//
//  SessionCard.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI

struct SessionCard: View {
    let session: Session
    
    var body: some View {
        ZStack{
            VStack {
                ZStack {
                    backgroundView
                    Text(session.emoji)
                        .font(.system(size: 60))
                }
                
                VStack(alignment: .center, spacing: 8) {
                    Text(session.title)
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text(session.subtitle)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Button(action: {
                    }) {
                        Text(session.isLocked ? "Locked" : "Start + \(session.pointsReward) XP")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(session.isLocked ? Color.gray : .theme)
                            .cornerRadius(20)
                    }
                    .disabled(session.isLocked)
                }
            }
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(20)
            .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 4)
            
            if session.isLocked {
                Rectangle()
                    .fill(.ultraThinMaterial.opacity(0.7))
                    .cornerRadius(20)
                    .edgesIgnoringSafeArea(.all)
                
                Image(systemName: "lock.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.primary)
            }
        }
    }
}

//#Preview {
//    VStack {
//        Spacer()
//        SessionCard(session: Session(emoji: "🍏", title: "Session 1", subtitle: "Divide and Conquer", isLocked: false, pointsReward: 70, topics: ["Algorithms", "Problem Solving"], difficulty: .beginner))
//            .frame(height: 250)
//            .padding()
//        SessionCard(session: Session(emoji: "🚀", title: "Session 2", subtitle: "Dynamic Programming", isLocked: true, pointsReward: 100, topics: ["Algorithms", "Optimization"], difficulty: .intermediate))
//            .frame(height: 250)
//            .padding()
//        Spacer()
//    }
//}
