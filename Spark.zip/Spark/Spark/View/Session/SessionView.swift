//
//  SessionView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI

struct SessionView: View {
    @Environment(\.modelContext) var context
    @State private var currentQuestionIndex = 0
    @State private var streak = 0
    @State private var selectedAnswer: String = ""
    @State private var showFeedback = false
    @State private var isCorrect = false
    @State private var correctAnswers = 0
    
    @State var assistantID: String
    
    @State private var ifInit: Bool = false
    @State private var isStreaming: Bool = false
    @State private var threadID: String = ""
    @State private var streamingResponse: String = ""
    
    @State private var errorMessage: String = ""
    @State private var showAlert: Bool = false
    
    @State var session: Session
    @State var gptClient = GPTClient()
    
    @State var questions: [Question] = []
    
    // FeedbackView states
    @State private var showLearnMore = false
    @State private var personalizedFeedback = ""
    
    // Timer states
    @State private var elapsedTime: TimeInterval = 0
    @State private var timer: Timer? = nil
    @ObservedObject var userManager: UserManager
    
    var body: some View {
        ZStack {
            VStack {
                ProgressBarView(progress: Double(currentQuestionIndex) / Double(questions.count), streak: streak)
                    .animation(.bouncy)
                
                if currentQuestionIndex < questions.count {
                    QuestionView(question: questions[currentQuestionIndex], onAnswerSelected: handleAnswer)
                } else {
                    Text("Session Complete!")
                        .font(.title)
                        .fontWeight(.bold)
                }
                
                Spacer()
            }
            
            if ifInit {
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .cornerRadius(20)
                    .edgesIgnoringSafeArea(.all)
                
                LoadingView(title: "Building Session")
            }
            
            
            if currentQuestionIndex == questions.count - 1 {
                SessionSummaryView(totalXP: 100, percentCorrect: Int(Double(correctAnswers) / Double(questions.count)), timeSpent: formatTime(elapsedTime))
                    .onAppear{
                        if let userId = userManager.currentUser?.id {
                            userManager.addSession(userId: userId, sessionId: session.id)
                            userManager.addXP(userId: userId, amount: session.pointsReward)
                            userManager.recordDailyActivity()
                        }
                    }
            }
        }
        .animation(.spring, value: ifInit)
        .background(.ultraThinMaterial)
        .onAppear {
            startStream()
            startTimer()
        }
        .onDisappear {
            stopTimer()
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Error"),
                message: Text(errorMessage),
                dismissButton: .default(Text("OK"))
            )
        }
        .sheet(isPresented: $showLearnMore) {
            learnMoreView
                .onAppear{
                    initializeFeedback()
                }
        }
        .sheet(isPresented: $showFeedback, content: {
            feedbackView
                .presentationDetents([.medium])
        })
    }
    
    private var feedbackView: some View {
        VStack {
            Spacer()
            VStack(spacing: 20) {
                Image(systemName: isCorrect ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .font(.system(size: 60))
                    .foregroundColor(isCorrect ? .green : .red)
                
                Text(isCorrect ? "Correct!" : "Incorrect")
                    .font(.title)
                    .fontWeight(.bold)
                
                if (!isCorrect) {
                    Text("Not quite. Try again!")
                        .font(.body)
                        .multilineTextAlignment(.center)
                }
                
                if isCorrect {
                    Text("🔥 Streak: \(streak)")
                        .font(.headline)
                        .foregroundColor(.orange)
                }
                
                VStack(spacing: 15) {
                    if !isCorrect {
                        Button(action: {
                            showLearnMore = true
                        }) {
                            Text("Learn More")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(.blue)
                                .cornerRadius(15)
                        }
                    }
                    
                    Button(action: continueFeedback) {
                        Text(!isCorrect ? "Try Again" : "Continue")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(!isCorrect ? Color.red : Color.green)
                            .cornerRadius(15)
                    }
                }
                .padding(.top)
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(20)
            .shadow(radius: 10)
            .frame(height: UIScreen.main.bounds.height / 2)
            .transition(.move(edge: .bottom))
        }
        .edgesIgnoringSafeArea(.all)
    }
    
    private var learnMoreView: some View {
        VStack(spacing: 20){
            Text("The correct answer is: \(questions[currentQuestionIndex].correctAnswer)")
                .font(.title3)
                .fontWeight(.bold)
            
            if isStreaming {
                LoadingView(title: "Generating Feedback...")
            } else {
                Text(personalizedFeedback)
                    .font(.headline)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
        }
        .padding()
        .padding(.top, 30)
        .overlay(
            Button(action: {
                showLearnMore = false
            }) {
                Image(systemName: "xmark")
                    .font(.headline)
                    .fontWeight(.black)
                    .foregroundStyle(.secondary)
            }.padding()
            , alignment: .topTrailing)
    }
    
    
    // Timer functions
    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            elapsedTime += 1
        }
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    private func formatTime(_ timeInterval: TimeInterval) -> String {
        let minutes = Int(timeInterval) / 60
        let seconds = Int(timeInterval) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    
    private func handleAnswer(_ answer: String) {
        selectedAnswer = answer
        isCorrect = answer == questions[currentQuestionIndex].correctAnswer
        showFeedback = true
        
        if isCorrect {
            correctAnswers += 1
            streak += 1
        } else {
            streak = 0
        }
    }
    
    private func continueFeedback() {
        showFeedback = false
        if isCorrect {
            nextQuestion()
        } else {
            selectedAnswer = ""
        }
    }
    
    private func nextQuestion() {
        if currentQuestionIndex < questions.count - 1 {
            currentQuestionIndex += 1
            selectedAnswer = ""
        }
    }
    
    private func startStream() {
        if(ifInit == false){
            ifInit = true
            let initInput = [
                "user_name": "Steven",
                "study_style": "Active"
            ] as [String : Any]
            print("init input", initInput)
            
            do{
                let initData = try JSONSerialization.data(withJSONObject: initInput, options: .prettyPrinted)
                if let initString = String(data: initData, encoding: .utf8) {
                    isStreaming = true
                    print("Starting stream with initial data: \(initData)")
                    Task {
                        do {
                            print("Creating thread with initial data...")
                            let run = try await gptClient.createThreadAndRun(assistantID, initString)
                            self.threadID = run.threadId
                            
                            _ = try await waitForRunCompletion(threadId: threadID, runId: run.id)
                            var questions = try await gptClient.listMessages(run.threadId)[0].convertToQuestions()
                            if let questions {
                                self.questions = questions
                                print("Stream started successfully.")
                                ifInit = false
                            } else {
                                errorMessage = "Can't initialize session"
                                showAlert = true
                                ifInit = false
                            }
                            
                        } catch {
                            errorMessage = "Error starting stream: \(error.localizedDescription)"
                            showAlert = true
                            print("Error starting stream: \(error.localizedDescription)")
                        }
                    }
                }
            }
            catch {
               errorMessage = "Failed to serialize initial data."
               showAlert = true
               print("Error: Failed to serialize initial data: \(error)")
           }
        }
    }
    
    private func waitForRunCompletion(threadId: String, runId: String) async throws -> String {
        var runStatus = ""
        repeat {
            try await Task.sleep(nanoseconds: 1_000_000_000)
            let runResult = try await gptClient.retrieveRun(threadId, runId)
            runStatus = runResult.status
        } while runStatus != "completed"
        return runStatus
    }
    
    private func initializeFeedback() {
        let initString = "Wrong answer for question: \(questions[currentQuestionIndex].title), student answer: \(selectedAnswer)"
        print("Serialized initial data: \(initString)")
        startFeedbackStream(with: initString)
    }
    
    private func startFeedbackStream(with initData: String) {
        isStreaming = true
        print("Starting stream with initial data: \(initData)")
        Task {
            do {
                self.personalizedFeedback = ""
                
                try GPTClient().streamRun(threadID, assistant_id: assistantID, onUpdate: { newData in
                    self.personalizedFeedback.append(newData)
                }, onComplete: {
                    isStreaming = false
                })
                
                questions[currentQuestionIndex].feedback = personalizedFeedback
                print("Stream started successfully.")
            } catch {
                errorMessage = "Error starting stream: \(error.localizedDescription)"
                print("Error starting stream: \(error.localizedDescription)")
            }
        }
    }
}
//
//struct SessionViews_Previews: PreviewProvider {
//    static var previews: some View {
////        let jsonString = """
////[
////  {
////    "title": "Understanding Reductions",
////    "description": "Reductions involve mapping a problem to another to find solutions.",
////    "questionType": "trueFalse",
////    "correctAnswer": "True",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "Polynomial Time Solution",
////    "description": "If Problem A reduces to Problem B and B can be solved in polynomial time, then A can also be solved in polynomial time.",
////    "questionType": "multipleChoice",
////    "correctAnswer": "A can be solved in polynomial time",
////    "choices": [
////      "A can be solved in polynomial time",
////      "A cannot be solved in polynomial time",
////      "The solution time cannot be determined"
////    ]
////  },
////  {
////    "title": "NP-Completeness",
////    "description": "A problem in 'NP-complete' is the hardest problem in NP.",
////    "questionType": "shortAnswer",
////    "correctAnswer": "True"
////  },
////  {
////    "title": "Properties of NP-Complete Problems",
////    "description": "For NP-complete problems, if one problem can be solved in polynomial time, all can be.",
////    "questionType": "trueFalse",
////    "correctAnswer": "True",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "Reduction of 3-SAT",
////    "description": "What is the reduction related to 3-SAT for proving NP-hardness?",
////    "questionType": "shortAnswer",
////    "correctAnswer": "3-SAT reduction to other NP-complete problems like Subset Sum and Independent Set"
////  },
////  {
////    "title": "Understanding Max Flow",
////    "description": "What problem can be reduced to the Maximum Flow problem?",
////    "questionType": "multipleChoice",
////    "correctAnswer": "Bipartite Matching",
////    "choices": [
////      "Traveling Salesperson Problem",
////      "Subset Sum",
////      "Bipartite Matching"
////    ]
////  },
////  {
////    "title": "Graph Coloring",
////    "description": "Can a graph coloring problem using three colors be related to 3-SAT?",
////    "questionType": "trueFalse",
////    "correctAnswer": "True",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "Subset Sum Complexity",
////    "description": "Subset Sum problem can be solved using dynamic programming. Is this solution polynomial?",
////    "questionType": "trueFalse",
////    "correctAnswer": "False",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "Independent Set Hardness",
////    "description": "Is proving an Independent Set of size K in a graph a hard problem?",
////    "questionType": "multipleChoice",
////    "correctAnswer": "Yes, it is NP-complete",
////    "choices": [
////      "No, it can be done in polynomial time",
////      "Yes, it is NP-complete",
////      "The difficulty varies with graph size"
////    ]
////  },
////  {
////    "title": "Characteristics of P vs NP",
////    "description": "What is the major unsolved question regarding P and NP?",
////    "questionType": "shortAnswer",
////    "correctAnswer": "Is P equal to NP?"
////  }
////]
////"""
//        
////        let jsonString = """
////[
////  {
////    "title": "What is one of the key advantages of database-driven marketing?",
////    "description": "Discusses personalized communications in database-driven marketing.",
////    "questionType": "multipleChoice",
////    "correctAnswer": "Increased customer loyalty",
////    "choices": [
////      "Increased customer loyalty",
////      "Decreased customer specificity",
////      "Higher advertising costs",
////      "Less need for data analysis"
////    ]
////  },
////  {
////    "title": "True or False: Buzz marketing is most effective when the product is kept secret.",
////    "description": "Explores the role of visibility in buzz marketing",
////    "questionType": "trueFalse",
////    "correctAnswer": "False",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "How does humor in advertising affect consumer memory?",
////    "description": "Understanding the effect of humor in advertising strategies.",
////    "questionType": "shortAnswer",
////    "correctAnswer": "Humor helps consumers laugh and remember the advertisement."
////  },
////  {
////    "title": "Which of these methods includes targeting without other channel members?",
////    "description": "Identifies the direct approach in marketing techniques.",
////    "questionType": "multipleChoice",
////    "correctAnswer": "Direct response marketing",
////    "choices": [
////      "Social media marketing",
////      "Direct response marketing",
////      "Traditional media advertising",
////      "SEO optimization"
////    ]
////  },
////  {
////    "title": "True or False: Recommendations by friends have a lower trust factor than TV advertisements.",
////    "description": "Compares trust factors of different advertising sources.",
////    "questionType": "trueFalse",
////    "correctAnswer": "False",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "Identify a key strategy that encourages brand evangelism.",
////    "description": "Involves creating a strong buzz around the brand.",
////    "questionType": "shortAnswer",
////    "correctAnswer": "Seeding opinion leaders with the product."
////  },
////  {
////    "title": "What is one major flaw of traditional media?",
////    "description": "Focuses on understanding the limitations of traditional media channels.",
////    "questionType": "multipleChoice",
////    "correctAnswer": "Trust issues",
////    "choices": [
////      "Trust issues",
////      "High engagement",
////      "Wide target reach",
////      "Cost efficiency"
////    ]
////  },
////  {
////    "title": "In marketing communication, what does 'CPR' stand for?",
////    "description": "Jargon clarification in marketing communication.",
////    "questionType": "shortAnswer",
////    "correctAnswer": "Cost Per Rating Point"
////  },
////  {
////    "title": "True or False: Personalized marketing generally yields a higher response rate.",
////    "description": "Determines effectiveness of personalized marketing.",
////    "questionType": "trueFalse",
////    "correctAnswer": "True",
////    "choices": ["True", "False"]
////  },
////  {
////    "title": "Which advertising appeal connects emotions with memories?",
////    "description": "Describes advertising appeals that enhance consumer connection.",
////    "questionType": "multipleChoice",
////    "correctAnswer": "Music",
////    "choices": [
////      "Fear",
////      "Humor",
////      "Sex",
////      "Music"
////    ]
////  }
////]
////"""
////        let jsonData = jsonString.data(using: .utf8)!
////        let decoder = JSONDecoder()
////        let insight = try! decoder.decode([Question].self, from: jsonData)
//        
//        Group {
//            // Preview SessionView
//            SessionView(assistantID: "asst_1XsI8ADbgvYyPE0R2X71uyb2", session: Session(emoji: "", title: "", subtitle: "", isLocked: false, pointsReward: 0, topics: [], difficulty: .advanced), userManager: UserManager())
//                .previewDisplayName("Session View")
//            
//            // Preview MultipleChoiceQuestionView
//            MultipleChoiceQuestionView(question: sampleQuestions[0], onAnswerSelected: { _ in })
//                .previewLayout(.sizeThatFits)
//                .padding()
//                .previewDisplayName("Multiple Choice")
//            
//            // Preview TrueFalseQuestionView
//            TrueFalseQuestionView(question: sampleQuestions[1], onAnswerSelected: { _ in })
//                .previewLayout(.sizeThatFits)
//                .padding()
//                .previewDisplayName("True/False")
//            
//            // Preview ShortAnswerQuestionView
//            ShortAnswerQuestionView(question: sampleQuestions[2], onAnswerSelected: { _ in })
//                .previewLayout(.sizeThatFits)
//                .padding()
//                .previewDisplayName("Short Answer")
//        }
//    }
//    
//    static var sampleQuestions: [Question] = [
//        Question(
//            title: "What's the capital of France?",
//            subTitle: "Choose the correct answer.",
//            questionType: .multipleChoice,
//            correctAnswer: "Paris",
//            choices: ["London", "Berlin", "Paris", "Madrid"]
//        ),
//        Question(
//            title: "Is the Earth flat?",
//            subTitle: "Answer true or false.",
//            questionType: .trueFalse,
//            correctAnswer: "False"
//        ),
//        Question(
//            title: "What's the largest planet in our solar system?",
//            subTitle: "Type your answer.",
//            questionType: .shortAnswer,
//            correctAnswer: "Jupiter"
//        )
//    ]
//}
