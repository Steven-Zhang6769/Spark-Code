//
//  ContentView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/19.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var items: [Item]
    @StateObject private var userManager = UserManager()

    var body: some View {
        NavigationStack {
            ZStack {
                if userManager.isLoading {
                    ProgressView()
                } else if userManager.currentUser != nil {
                    if ((userManager.currentUser?.enrolledCourse) != nil){
                        HomeView(userManager: userManager)
                    }else{
                        CourseListView(userManager: UserManager())
                    }
                } else {
                    LoginView(userManager: userManager)
                }
            }
            .background(.ultraThinMaterial)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .toolbarTitleDisplayMode(.inline)
            .tint(.primary)
        }
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Item.self, inMemory: true)
}
