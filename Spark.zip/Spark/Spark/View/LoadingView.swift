//
//  LoadingView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import SwiftUI

struct LoadingView: View {
    var title: String
    var onDismiss: (() -> Void)?
    var onCancel: (() -> Void)?

    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack(alignment: .center){
                ProgressView() {
                    Text(title)
                        .foregroundStyle(.secondary)
                        .padding(.vertical)
                        .multilineTextAlignment(.center)
                    
                    if let onCancel = onCancel {
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            onCancel()
                        }) {
                            HStack {
                                Text("Cancel")
                            }
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.red)
                            .cornerRadius(10)
                        }
                    }
                }
            }
            .frame(width: 200, height: 200)

            if let onDismiss = onDismiss {
                XButton(action: onDismiss, size: 25)
                    .padding(15)
            }
        }
        .frame(width: 200, height: 200)
        .background(
            .thinMaterial
        )
        .cornerRadius(20)
        .shadow(radius: 10)
    }
}

#Preview {
    LoadingView(title: "Loading")
}
