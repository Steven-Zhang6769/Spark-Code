//
//  LoginView.swift
//  Spark
//
//  Created by Shuhan Zhang on 2024/10/20.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var isRegistering = false
    @ObservedObject var userManager: UserManager
    
    var body: some View {
        VStack {
            Text(isRegistering ? "Register" : "Login")
                .font(.largeTitle)
                .padding()
            
            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: isRegistering ? registerUser : loginUser) {
                Text(isRegistering ? "Register" : "Login")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding(.horizontal)
            
            Button(action: { isRegistering.toggle() }) {
                Text(isRegistering ? "Already have an account? Login" : "Don't have an account? Register")
                    .foregroundColor(.blue)
            }
            .padding()
            
            Text(errorMessage)
                .foregroundColor(.red)
                .padding()
        }
        .padding()
    }
    
    func loginUser() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else if let user = result?.user {
                userManager.fetchUser(userId: user.uid)
            }
        }
    }
    
    func registerUser() {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else if let user = result?.user {
                userManager.createUser(userId: user.uid) { result in
                    switch result {
                    case .success(let user):
                        print("User successfully created and added to Firestore: \(user)")
                    case .failure(let error):
                        errorMessage = "Failed to create user in Firestore: \(error.localizedDescription)"
                    }
                }
            }
        }
    }
}

#Preview {
    LoginView(userManager: UserManager())
}
